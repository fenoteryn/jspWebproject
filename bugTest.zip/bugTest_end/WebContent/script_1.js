	function Update(mem_id){
		document.update.mem_id.value=mem_id;
		document.update.submit();
	}

//board

	function talkBoardDetail(no) {
		document.detail.no.value=no;
		document.detail.submit();
	}
	function productDelete(no) {
		document.del.no.value=no;
		document.del.submit();
	}
	function productUpdate(no){
		document.update.no.value=no;
		document.update.submit();
	}

//menu_kategory
	
	function menukate_l(kate){
		document.KeyWord_l.KeyWord.value = kate;
		document.KeyWord_l.submit();
	}
	
	function menukate_f(kate){
		document.KeyWord_f.KeyWord.value =kate;
		document.KeyWord_f.submit();
	}
	
//comment
	
	function productDelete(no) {
		document.del.no.value=no;
		document.del.submit();
	}

	function productUpdate(no){
		document.update.no.value=no;
		document.update.submit();
	}