package bugTest;


public class PlayBean {

    private int no = 0;
    private String name = null;
    private String image = null;
    private String kate = null;
    private String jsp = null;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    public void  setKate(String kate) {
    	this.kate = kate;
    }
    
    public String getKate() {
    	return kate;
    }
    
    public void setJsp(String jsp) {
    	this.jsp = jsp;
    }
    
    public String getJsp() {
    	return jsp;
    }

}
